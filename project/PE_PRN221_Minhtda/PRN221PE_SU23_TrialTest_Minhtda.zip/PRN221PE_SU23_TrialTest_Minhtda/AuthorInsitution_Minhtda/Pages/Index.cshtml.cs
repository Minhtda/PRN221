﻿using BusinessObject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Repository;

namespace AuthorInsitution_Minhtda.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public MemberAccount Account { get; set; }
        public IActionResult OnGet()
        {
            return Page();
        }
        public string msg { get; set; }
        private readonly IMemberAccountRepository _Repository;
        public IndexModel(IMemberAccountRepository Repository)
        {
            _Repository = Repository;
        }
        public async Task<IActionResult> OnPostAsync()
        {

            try
            {
                var acc = _Repository.GetMemberAccountByEmail(Account.EmailAddress, Account.MemberPassword);

                if (acc is not null)
                {
                    if (acc.MemberRole == 1)
                    {
                        return RedirectToPage("./CorrespondingAuthors/Index");
                    }
                }
                msg = "Invalid Account";
                return Page();
                
            }
            catch (Exception ex)
            {

            }

            return Page();

        }
    }
}
